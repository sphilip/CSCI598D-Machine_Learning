Shanley Philip
Doug Welch
CSCI 598D:Machine Learning

To compile: 
   Run the compile.sh script in the terminal (./compile.sh <# of games).  

   The script will clean the current directory of related project files, 
       compile the necessary files (as defined in the Makefile).

   If no number is included for the number of games, the script will fail 
      safely.
