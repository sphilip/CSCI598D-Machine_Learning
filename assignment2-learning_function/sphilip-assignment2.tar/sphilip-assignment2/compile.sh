#!/bin/bash

if [ $# != 1 ] 
then
    echo "To compile, type ./compile.sh <# of iterations>"
else
    make clean
    make 
    ./tictactoe $1 > "$1.txt"
    less "$1.txt"
fi
